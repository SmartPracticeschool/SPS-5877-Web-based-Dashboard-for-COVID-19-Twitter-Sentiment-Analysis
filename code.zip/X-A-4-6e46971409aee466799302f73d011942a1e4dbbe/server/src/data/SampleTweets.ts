const tweets = [
  {
    text: '@JetBlue @FLLFlyer Are conditions always this bad at your airport? (Crowds, heat, mess, broken equipment)',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@gregkoch1 @united I miss continental airlines',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united my flight #4806 got cancelled and ur people at the gate said there\'s no way to compensate. Wanna earn some good PR &amp; help me out?',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united poor Customer service! I was told I didn\'t have enough time to check in my bag and had to forfeit my flight. @AmericanAir saved me!',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@JetBlue @AmericanAir let\'s all laugh at that one time we all thought it was safe to fly on an @Delta flight.',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '.@united used to be Continental base here in #Houston. They were GREAT! Free meal, movie. Now gotta pay for EVERYTHING. Rude stewardesses.',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united no I needed someone to check in the bag. According to airport employee, station manager busy on his cell phone',
    post_date: '2017-07-08T22:37:52.844Z',
  },
  {
    text: '@JetBlue @AmericanAir has the worst customer service in the history of time. Never had a nice person at the desk. Ever.',
    post_date: '2017-07-08T22:37:52.844Z',
  },
  {
    text: '@united are you guys going to call me to tell me how to proceed?',
    post_date: '2017-07-08T22:37:52.844Z',
  },
  {
    text: 'Let me tell you. .@united is freaking JOKE of an airline! They changed the get on us and didn\'t tell us. Just got lucky &amp; noticed.',
    post_date: '2017-07-08T22:37:52.844Z',
  },
  {
    text: 'Yet again, no @United ticket agents for premier access &amp; only 2 for economy #fail #travelwoes #Austin https://t.co/Js3qQnadgA',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@Gary_Fisher @united Maybe they paused to beat the shit out of a paying customer?',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@JetBlue Do I need to come to the Emirates counter first or JetBlue?',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united plz learn from @AlaskaAir when it comes to rfnding tkts to your top fliers.1Kon @united, 75Kon @AlaskaAir..moving away from @united',
    post_date: '2017-08-08T22:37:52.844Z',
  },
  {
    text: 'Having a support system helps us understand what is happening for all #stakeholders. How @united failed: https://t.co/prWHAxIxY9 #united',
    post_date: '2017-08-08T22:37:52.844Z',
  },
  {
    text: 'My family stuck in Dublin because of inept employees of @AerLingus.  Irony is that they bought new ticket on @united. Never again @AerLingus',
    post_date: '2017-08-08T22:37:52.844Z',
  },
  {
    text: 'I\'m on a @united flight home right now, and I\'m already seated. If I get bumped I\'m taking it as a sign that we should just move to Chicago.',
    post_date: '2017-08-08T22:37:52.844Z',
  },
  {
    text: '@united one to kick some but at STL. Baggage wait times are getting longer and longer. #frequentflyer',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united and here I tried to stand by you even after you beat that guy up! Didn\'t know I wasn\'t good enough to KEEP MY LUGGAGE!',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united when did you roll out peasant class that doesn\'t allow me a carry on and personal item? Can\'t even check in on app! No peasants!',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: 'Good luck!! United customer service is terrible. https://t.co/Dz5HwtO4fl',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united what is the best way to track down my lost bag? Received a msg it was not on our flight to Europe and the bag trace doesn\'t show it',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united So, was just told I couldn\'t use an RPE, paid with cash for the upgrade. Then was told there is no upgrade. After paying. Wtf?',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@united would be great if you were more communicative about what is happening instead of watching your employees laugh at the gate',
    post_date: '2017-09-08T22:37:52.844Z',
  },
  {
    text: 'Colgate and #Cowshed? nice case, but that makes for a subpar amenity kit @united https://t.co/Ljmv0GwSSy so many better products out there!',
    post_date: '2017-09-08T22:37:52.844Z',
  },
  {
    text: 'Lessons to learn from @united: be more responsive and personable in social media responses #SloanieReunion',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@JetBlue Fligth 462 SJU - BOS the worst service in my life',
    post_date: '2017-09-08T22:37:52.844Z',
  },
  {
    text: 'You would think they learned their lesson https://t.co/wGnGTv1pgB',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: '@Dawnkubik @Gerjersey @JLaValle @united Dawn if you live in NJ and fly 200k miles a year there aren\'t many options https://t.co/U0ZLHhR3k2',
    post_date: '2017-06-08T22:37:52.844Z',
  },
  {
    text: 'This &amp; many other reasons are why I cashed in my miles &amp; stopped flying @united airlines. Do you hire anyone with b https://t.co/bWLEDEphD6',
    post_date: '2017-06-08T22:37:52.844Z',
  },
];

export default tweets;
