export const config = {
  logging: false,
};
