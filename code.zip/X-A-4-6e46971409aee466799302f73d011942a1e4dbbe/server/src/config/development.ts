export const config = {
  logging: true,
};
