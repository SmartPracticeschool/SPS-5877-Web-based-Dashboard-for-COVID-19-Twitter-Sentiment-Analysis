#!/usr/bin/env python
# keys.py
# visit http://dev.twitter.com to create an application and get your keys
keys = dict(
    consumer_key='YOUR KEY HERE',
    consumer_secret='YOUR KEY HERE',
    access_token='YOUR KEY HERE',
    access_token_secret='YOUR KEY HERE',
    ibm_key="YOUR KEY HERE",
    ibm_url="YOUR KEY HERE",
)

reddit_keys = dict(
    C_id="YOUR KEY HERE",
    C_secret="YOUR KEY HERE",
    User_agent="YOUR KEY HERE",
    Uname="YOUR KEY HERE",
    Password="YOUR KEY HERE",
)

# note: write your keys inside the quotes.
